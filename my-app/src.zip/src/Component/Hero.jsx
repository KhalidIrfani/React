import { Box, Button, Grid,Typography } from "@mui/material";
import Rectangle from './images/Rectangle.png';
import React from "react";
 

const Hero = () => {

    return (
        <Box>
            <Grid container  display="flex" justifyContent="space-between">
                <Grid item xs={12} md={6} >
                    <Box sx={{color:'white',alignItems:"center", marginLeft:{md:"9rem", xs:"1rem"}, marginTop:{md:"7rem", xs:"2rem"} }}>
                        <Typography  sx={{fontSize:{md:"4rem",xs:"2rem"}, fontWeight:{md:"Bold",xs:"bold"}}}>Bridge the <br /> Gap</Typography>
                        <Typography sx={{fontSize:{xs:".8rem",md:"1.2rem"}}}>Lorem ipsum dolor,
                            consectetur adipiscing <br /> elit  Pellentesque aliquet
                             libero eu volutpat <br />sss hendrerit,
                             dolor dui consectetur dolor <br /> leo.</Typography> 
                        <Button  sx={{background:"#EF2779", color:"white", margin:"1rem", borderRadius:"2rem", paddingLeft:"2rem", paddingRight:"2rem"}}>REGISTER</Button>
                        <Button  sx={{background:"gray",color:"white", borderRadius:"2rem", paddingLeft:"2rem", paddingRight:"2rem"}}>REVIEW</Button>
                    </Box>
                </Grid>

                <Grid item xs={12} md={5}>
                    <Box sx={{marginTop:{md:"-5rem", xs:"-2rem"}}}>
                        <img src={Rectangle} alt="rectangle" />
                    </Box>
                </Grid>
            </Grid>
        </Box>
    )
}
export default Hero;
