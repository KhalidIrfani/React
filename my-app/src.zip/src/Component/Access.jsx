import { Button, TextField, Typography } from "@mui/material";
import mail from "./../Component/images/mail.png"
import { Box } from "@mui/system";
import { styled } from "@mui/material/styles";
import React from "react";

const CssTextField = styled(TextField)({
    "&.MuiInput:undeline:before": {
        borderBottomColor: "white"
    }
})

const Access = () => {
    return (
        <Box>
            <Typography sx={{ color: "White", fontSize: { xs: "1rem", md: "1.5rem" }, fontWeight: "bold", textAlign: "center", marginTop: "3rem", marginRight: { xs: "4rem" } }}>
                At your fingertips
            </Typography>
            <Typography sx={{ color: "White", fontSize: { xs: ".85rem", md: "2rem" }, textAlign: "center", marginTop: "1rem", marginRight: { xs: "5rem" } }}>
                Access or upload anything in an instant of time
            </Typography>
            <Typography sx={{ color: "White", fontSize: { xs: "1rem", md: "1.5rem" }, textAlign: "center", marginTop: "3rem", marginRight: { xs: "5rem" } }}>
                Subscribe to our Website
            </Typography>

            <Typography sx={{ color: "White", fontSize: { xs: "1rem", md: "1.5rem" }, textAlign: "center", marginTop: " .5rem", marginRight: { xs: "5rem" } }}>
                Available exclusivery
            </Typography>

            <Typography align="center" marginTop={4} paddingLeft={3} paddingRight={3} borderRadius="4rem" sx={{ color: "white", marginRight: { xs: "6.5rem" } }}>
                <CssTextField label="Your email" variant="outlined" InputLabelProps={{
                    style: {
                        color: 'White',
                    },
                }} />
            </Typography>
            <Typography align="center" ><Button sx={{ background: "#EF2779", color: "White", textalign: "center", margin: "1.5rem", marginRight: { xs: "7rem" }, borderRadius: "2rem", paddingLeft: "5rem", paddingRight: "5rem" }}>Suscribe</Button>
            </Typography>
            <Typography align="end" marginRight={22} marginTop={-17}><img src={mail} alt="mail" height={130} /></Typography>

        </Box>
    )
}

export default Access