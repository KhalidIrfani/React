
import { Button, Grid, Typography, } from "@mui/material";
import { Box } from "@mui/system";



const Navbar = () => {


    return (
        <Box sx={{ paddingTop: "1rem" }}>

            <Grid display="flex"
                sx={{
                    width: {
                        md: "50%",
                        xs: "100%"
                    },
                    marginLeft: {
                        md: "2.5rem",
                        xs: "0rem"
                    }
                }}>
                <Grid Item md={4}  >
                    <Button sx={{ color: 'white' }}><Typography sx={{ fontSize: { md: "1.5rem", xs: ".75rem" } }}>BRIDGE</Typography></Button>
                    <Button sx={{ color: 'white', marginLeft: { md: "1rem", xs: "0rem" } }}><Typography sx={{ fontSize: { xs: ".65rem", md: ".9rem" } }}>Plan</Typography></Button>
                    <Button sx={{ color: 'white' }}><Typography sx={{ fontSize: { xs: ".65rem", md: ".9rem" } }}>Guide</Typography>
                    </Button>


                    <Button sx={{ color: 'white', marginLeft: { md: "16rem", xs: "0rem" }, }} ><Typography sx={{ fontSize: { md: ".9rem", xs: ".65rem" } }}>Sing Up</Typography></Button>
                    <Button sx={{ color: 'white' }} ><Typography sx={{ fontSize: { md: ".9rem", xs: ".65rem" } }}>LogIn</Typography></Button>
                </Grid>

            </Grid>
            <Box sx={{ color: "E8EAED", width: "48%", marginLeft: "3rem", marginTop: "-.5rem" }}>
                <hr />
            </Box>
        </Box>
    )
}

export default Navbar;