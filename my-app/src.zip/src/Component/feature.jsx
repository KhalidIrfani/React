import { Box } from "@mui/system";
import clock from "./../Component/images/clock.png"
import analytics from "./../Component/images/analytics.png"
import profile from "./../Component/images/profile.png"
import social from "./../Component/images/social.png"
import React from "react";
import { Grid, Typography } from "@mui/material";

const Feature = () => {
    return (
        <Box >

            <Box sx={{ color: "white", textAlign: "center", marginRight:{xs:"6rem"}}}>
          <Typography  sx={{fontSize:{xs:"1.2rem",md:"3rem"}, fontWeight:"bold"}}>Feature</Typography>
                <Typography sx={{fontSize:{xs:".85rem", md:"1rem"}}}>Lorem ipsum dolor sit amet consectetur <br /> adipisicing elit. Ipsam, similique.</Typography>
            </Box>
            <Box >                              
                <Box sx={{ color: "white", marginTop:"2rem" }}>
                    <Grid  container>
                    <Grid item xs={12} md={3}  marginLeft={{md:7,xs:5}} >
                    <img src={clock} alt="clock" />
                    <Typography marginTop={1}>Lorem ipsum dolor sit amet,  <br /> adipisicing elit. Magnam, fuga.</Typography>
                </Grid>
                <Grid item xs={12} md={3}  marginTop={{md:3.5, xs:3}} marginLeft={{xs:6, md:0}} >
                    <img src={analytics} alt="analytics" height={80} width={140} marginLeft={{xs:5}}/>
                  < Typography  marginTop={4}> <p>Lorem ipsum dolor sit amet, <br /> adipisicing elit. Magnam, fuga.</p></Typography> 
                </Grid>
                <Grid item xs={12} md={3} marginTop={4} marginLeft={{xs:6, md:0}}>
                    <img src={profile} alt="profile" />
                    <Typography marginTop={1}>Lorem ipsum dolor sit amet, <br /> adipisicing elit. Magnam, fuga.</Typography>
                </Grid>
                <Grid item xs={12} md={2} marginRight={3} marginTop={3.5} marginLeft={{xs:6, md:0}}>
                    <img src={social} alt="social" />
                    <Typography marginTop={2}>Lorem ipsum dolor sit amet, <br /> adipisicing elit. Magnam, fuga.</Typography>
                </Grid>
                    </Grid>
               
                </Box>
            </Box>



        </Box>
    )
}
export default Feature