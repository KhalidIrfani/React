import { Box } from '@mui/system';
import './App.css';
import Home from './Page/Home';
 

function App() {
  return (
    <Box bgcolor="black">
     <Home />
    </Box>

  );
}

export default App;
